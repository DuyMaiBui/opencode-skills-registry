---
name: hello-world
description: <description>
---

# hello-world

## Use This Skill When
- <context>

## Rules
- <rule 1>
- <rule 2>
